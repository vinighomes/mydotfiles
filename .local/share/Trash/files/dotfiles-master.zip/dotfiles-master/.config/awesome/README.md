# Awesome4Laptop

Installation:

	git clone https://github.com/msjche/Awesome4Laptop.git ~/.config/awesome
	cd ~/.config/awesome && cp -r Awesome4Laptop/* .
	rm -r Awesome4Laptop

![Alt text](screenshot.png?raw=true "Title")
