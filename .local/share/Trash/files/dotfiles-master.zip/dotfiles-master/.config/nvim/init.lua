require("dt.base") -- General Settings
require("dt.highlights") -- Colourscheme and other highlights
require("dt.maps") -- Keymaps
require("dt.plugins") -- Plugins
require("dt.bootstrap") -- Packer Auto-Installer
